package com.cg.stepdefinitions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import com.cg.pagebean.RegisterPf;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RegisterSd {
	static WebDriver driver;
	private RegisterPf registerPf;
	@Before
	public void openBrowser() {

		String driverPath = "D:\\Selenium\\";
		System.setProperty("webdriver.chrome.driver", driverPath+"chromedriver.exe");	
		driver = new ChromeDriver();



	}
	@Given("^User is on registration page$")
	public void user_is_on_registration_page() throws Throwable {
		registerPf=new RegisterPf(driver);
		driver.get("file:///D:/Selenium/Lesson%205-HTML%20Pages/WorkingWithForms.html");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@When("^user enters all data as valid and clicks the submit button$")
	public void user_enters_all_data_as_valid_and_clicks_the_submit_button() throws Throwable {


		registerPf.setUserName("aanchal123");
		registerPf.setPassword("aanchal");
		registerPf.setcPassword("aanchal");
		registerPf.setfName("Aanchal");
		registerPf.setlName("Srivastava");
		registerPf.setRbFemale();
		registerPf.setDob("09/26/1996");
		registerPf.setEmail("aanchal26@gmail.com");
		registerPf.setAddress("rajajipuram");
		registerPf.setCity("Mumbai");
		registerPf.setPhone("9985236756");
		registerPf.setHobbies();
		registerPf.setSubmit();


	}


	@Then("^display success page$")
	public void display_success_page() throws Throwable {
		driver.navigate().to("file:///D:/Selenium/Lesson%205-HTML%20Pages/WorkingWithForms.html");
	}
	@When("^user enters password and confirm password as different$")
	public void user_enters_password_and_confirm_password_as_different() throws Throwable {
		registerPf.setUserName("aanchal123");
		registerPf.setPassword("aanchal");
		registerPf.setcPassword("sahgfhb");
		registerPf.setfName("");
	}

	@Then("^give alert message , click the reset button and enter all valid data$")
	public void give_alert_message_click_the_reset_button_and_enter_all_valid_data() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		System.out.println("******" + alertMessage);
		registerPf.setReset();
		registerPf.setUserName("aanchal123");
		registerPf.setPassword("aanchal");
		registerPf.setcPassword("aanchal");
		registerPf.setfName("Aanchal");
		registerPf.setlName("Srivastava");
		registerPf.setRbFemale();
		registerPf.setDob("09/26/1996");
		registerPf.setEmail("aanchal26@gmail.com");
		registerPf.setAddress("rajajipuram");
		registerPf.setCity("Mumbai");
		registerPf.setPhone("9985236756");
		registerPf.setHobbies();

	}
}
