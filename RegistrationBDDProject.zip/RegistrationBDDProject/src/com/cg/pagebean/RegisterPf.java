package com.cg.pagebean;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class RegisterPf {
	WebDriver driver;
	public RegisterPf(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	@FindBy(name="txtUName")
	@CacheLookup
	WebElement userName;
	
	@FindBy(how=How.ID,using="txtPassword")
	@CacheLookup
	WebElement password;
	
	@FindBy(how=How.ID,using="txtConfPassword")
	@CacheLookup
	WebElement cPassword;
	
	@FindBy(how=How.ID,using="txtFirstName")
	@CacheLookup
	WebElement fName;

	@FindBy(how=How.ID,using="txtLastName")
	@CacheLookup
	WebElement lName;
	
	@FindBy(how=How.ID,using="rbFemale")
	@CacheLookup
	WebElement rbFemale;
	
	@FindBy(how=How.ID,using="DOB")
	@CacheLookup
	WebElement dob;
	
	@FindBy(how=How.ID,using="txtEmail")
	@CacheLookup
	WebElement email;
	
	@FindBy(how=How.ID,using="txtAddress")
	@CacheLookup
	WebElement address;
	
	@FindBy(name="City")
	@CacheLookup
	WebElement city;
	
	@FindBy(how=How.ID,using="txtPhone")
	@CacheLookup
	WebElement phone;
	
	@FindBy(name="chkHobbies")
	@CacheLookup
List<WebElement> hobbies;
	
	@FindBy(xpath="html/body/form/table/tbody/tr[13]/td/input")
	@CacheLookup
	WebElement submit;
	
	@FindBy(xpath=".//*[@id='myStyle']")
	@CacheLookup
	WebElement reset;
	
	
	public WebElement getUserName() {
		return userName;
	}

	public void setUserName(String uName) {
		userName.sendKeys(uName);;
	}

	public WebElement getPassword() {
		return password;
	}

	public void setPassword(String pwd) {
		password.sendKeys(pwd);;
	}

	public WebElement getcPassword() {
		return cPassword;
	}

	public void setcPassword(String cPwd) {
		cPassword.sendKeys(cPwd);
	}

	public WebElement getfName() {
		return fName;
	}

	public void setfName(String fn) {
		fName.sendKeys(fn);
	}

	public WebElement getlName() {
		return lName;
	}

	public void setlName(String ln) {
		lName.sendKeys(ln);
	}

	public WebElement getRbFemale() {
		return rbFemale;
	}

	public void setRbFemale() {
		this.rbFemale.click();
	}
		
	

	public WebElement getDob() {
		return dob;
	}

	public void setDob(String db) {
		dob.sendKeys(db);
	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String mail) {
		email.sendKeys(mail);
	}

	public WebElement getAddress() {
		return address;
	}

	public void setAddress(String add) {
		address.sendKeys(add);
	}

	public WebElement getCity() {
		return city;
	}

	public void setCity(String cty) {
		Select cityDrop=new Select(this.city);
		cityDrop.selectByValue(cty);
	}

	public WebElement getPhone() {
		return phone;
	}


	public void setPhone(String ph) {
		phone.sendKeys(ph);
	}



	public void setHobbies()  {
		for(WebElement webElement:hobbies) {
			webElement.click();
		}
	}

	public WebElement getSubmit() {
		return submit;
	}

	public void setSubmit() {
		this.submit.click();
	}

	public WebElement getReset() {
		return reset;
	}

	public void setReset() {
		this.reset .click();
	}
	
	

}
