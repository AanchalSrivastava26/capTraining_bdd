package com.cg.test;

import java.util.concurrent.TimeUnit;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.Before;

public class HotelBookingWebDriver {
static String driverPath = "D:\\Selenium\\ChromeDriver\\";
	
	private WebDriver driver;
	
	
	@Before
	public void openBrowsser() {
		//driver = new FirefoxDriver();
		System.setProperty("webdriver.chrome.driver", driverPath+"chromedriver.exe");	
		driver = new ChromeDriver();
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	

	driver.get("http://demo.opencart.com/");
	}

}
