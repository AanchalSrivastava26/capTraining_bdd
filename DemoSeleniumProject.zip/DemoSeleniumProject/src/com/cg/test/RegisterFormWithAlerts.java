package com.cg.test;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class RegisterFormWithAlerts {
	static WebDriver driver=null;
	static String alertMessage=null;



	public static void main(String[] args) {
		String driverPath = "D:\\Selenium\\";
		System.setProperty("webdriver.chrome.driver", driverPath+"chromedriver.exe");	
		driver = new ChromeDriver();
		//	WebDriver driver=new FirefoxDriver();
		driver.get("file:///D:/HTML_CSS/form2.html");
		String title=driver.getTitle();
		System.out.println("The page title is :" + title);
		/******* For valid user name *******/
		//driver.findElement(By.id("user")).sendKeys("Aanchal");

		/******* For blank user name *******/

		driver.findElement(By.id("user")).sendKeys("");
		driver.findElement(By.id("submitButton")).click();	
		callAlert();
	}
		public static void callAlert()
		{
			 alertMessage= driver.switchTo().alert().getText();
			System.out.println(alertMessage);		
			driver.switchTo().alert().accept();

		}
	}

