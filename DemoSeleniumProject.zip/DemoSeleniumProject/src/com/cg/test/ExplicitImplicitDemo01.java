package com.cg.test;


import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ExplicitImplicitDemo01 {
	public static void main(String[] args) throws InterruptedException {
		//WebDriver driver=new FirefoxDriver();
		 String driverPath = "D:\\Selenium\\";
			System.setProperty("webdriver.chrome.driver", driverPath+"chromedriver.exe");	
			WebDriver driver = new ChromeDriver();
	//driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.get("https://demo.opencart.com/");
		WebDriverWait wait=new WebDriverWait(driver,10);
		Date strtDate=new Date();
		System.out.println(strtDate);
		WebElement searchBox=wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("search")));
		Date endDate=new Date();
		System.out.println(endDate);
		searchBox.sendKeys("Phone");
		
		driver.findElement(By.className("input-group-btn")).click();
		
	}
}
