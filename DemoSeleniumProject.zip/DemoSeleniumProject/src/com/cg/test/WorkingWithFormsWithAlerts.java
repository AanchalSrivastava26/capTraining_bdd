package com.cg.test;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class WorkingWithFormsWithAlerts {

	static WebDriver driver;
	static String alertMessage=null;

	public static void main(String[] args) throws InterruptedException {
		String driverPath = "D:\\Selenium\\";
		System.setProperty("webdriver.chrome.driver", driverPath+"chromedriver.exe");	
		driver = new ChromeDriver();
		driver.get("file:///D:/Selenium/Lesson%205-HTML%20Pages/WorkingWithForms.html");
		driver.findElement(By.id("txtUserName")).sendKeys("aanchal123");
		Thread.sleep(200);
		driver.findElement(By.name("txtPwd")).sendKeys("aanchal");
		Thread.sleep(200);
		driver.findElement(By.className("Format")).sendKeys("bsajhfb");
		Thread.sleep(200);
		driver.findElement(By.cssSelector("input.Format1")).sendKeys("Aanchal");
		Thread.sleep(1000);
		callAlert();
		driver.findElement(By.xpath(".//*[@id='myStyle']")).click();
		//driver.navigate().refresh();
		driver.findElement(By.id("txtUserName")).sendKeys("aanchal123");
		Thread.sleep(200);
		driver.findElement(By.name("txtPwd")).sendKeys("aanchal");
		Thread.sleep(200);
		driver.findElement(By.className("Format")).sendKeys("aanchal");
		Thread.sleep(200);
		driver.findElement(By.cssSelector("input.Format1")).sendKeys("Aanchal");
		Thread.sleep(200);
		driver.findElement(By.name("txtLN")).sendKeys("Srivastava");
		Thread.sleep(200);
		driver.findElement(By.cssSelector("input[value='Female']")).click();
		Thread.sleep(200);
		driver.findElement(By.name("DtOB")).sendKeys("09/26/1996");
		Thread.sleep(200);
		driver.findElement(By.name("Email")).sendKeys("aanchalsrivastava26@gmail.com");
		Thread.sleep(200);

		driver.findElement(By.name("Address")).sendKeys("rajajipuram");
		Select drpCity=new Select(driver.findElement(By.name("City")));
		drpCity.selectByVisibleText("Mumbai");

		driver.findElement(By.xpath(".//*[@id='txtPhone']")).sendKeys("9153451721");

		List<WebElement>element=driver.findElements(By.name("chkHobbies"));
		for(WebElement val:element) {
			val.click();

		}
		String actualTitle;
		actualTitle=driver.getTitle();
		System.out.println("page title is :"+actualTitle);
		String expectedTitle="Email Registration Form";
		Boolean b=driver.getPageSource().contains("Email Registration Form");
		if(b==true)
			System.out.println("passed");
		else
			System.out.println("failed");
		String currentURL;
		currentURL=driver.getCurrentUrl();
		System.out.println("page current url is :"+currentURL);
		driver.findElement(By.name("submit")).click();
	}
	public static void callAlert()
	{
		String alertMessage= driver.switchTo().alert().getText();
		System.out.println(alertMessage);		
		driver.switchTo().alert().accept();

	}
}
