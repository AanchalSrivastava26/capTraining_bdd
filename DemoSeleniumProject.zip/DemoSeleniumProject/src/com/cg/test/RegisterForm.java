package com.cg.test;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class RegisterForm {

	public static void main(String[] args) {
		WebDriver driver=new FirefoxDriver();
		driver.get("file:///D:/HTML_CSS/form2.html");

		driver.findElement(By.id("user")).sendKeys("Aanchal Srivastava");
		driver.findElement(By.name("pwd")).sendKeys("aanchal");
		driver.findElement(By.xpath("html/body/table/tbody/tr[3]/td/input")).sendKeys("9153451721");

		WebElement femaleRadioBtn = driver.findElement(By.id("g_female"));
		boolean radioBtnIsDisplayed = femaleRadioBtn.isDisplayed();
		System.out.println("Is female radio button displayed: "+radioBtnIsDisplayed);
		boolean radioBtnIsEnabled = femaleRadioBtn.isEnabled();
		System.out.println("Is female radio button enabled: "+radioBtnIsEnabled);
		femaleRadioBtn.click();
		driver.findElement(By.name("date_of_birth")).sendKeys("26/09/1996");
		driver.findElement(By.name("email")).sendKeys("aanchalsrivastava26@gmail.com");
		Select drpQualification=new Select(driver.findElement(By.name("h_qualification")));
		drpQualification.selectByVisibleText("B.tech");

		List<WebElement>element=driver.findElements(By.name("tech"));
		for(WebElement val:element) {
			val.click();
			try {
				Thread.sleep(500);
			}
			catch (InterruptedException e) {
				System.out.println(e.getMessage());
			}
		}
		String actualTitle;
		actualTitle=driver.getTitle();
		System.out.println("page title is :"+actualTitle);
		String expectedTitle="Trainee Registration Form";
		Boolean b=driver.getPageSource().contains(expectedTitle);
		if(b==true)
			System.out.println("passed");
		else
			System.out.println("failed");

		String currentURL;
		currentURL=driver.getCurrentUrl();
		System.out.println("page current url is :"+currentURL);
		WebElement element2= driver.findElement(By.id("textArea"));
		element2.clear();
		element2.sendKeys("this is textArea");

		driver.findElement(By.id("myFile")).sendKeys("D:\\Users\\ADM-IG-HWDLAB2E\\Documents\\New folder");
		driver.findElement(By.name("submitButton")).click();
		driver.close();
	}
}
