
package com.cg.test;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class WorkingWithForms {

	public static void main(String[] args) {
		WebDriver driver=new FirefoxDriver();
		driver.get("file:///D:/Selenium/Lesson%205-HTML%20Pages/WorkingWithForms.html");
		try {
			//for username
			driver.findElement(By.id("txtUserName")).sendKeys("Aanchal123");
			Thread.sleep(10000);
			//for password
			driver.findElement(By.name("txtPwd")).sendKeys("aanchal");
			Thread.sleep(10000);
			//for confirm password
			driver.findElement(By.className("Format")).sendKeys("aanchal");
			Thread.sleep(10000);

		}
		catch (Exception e) {
			System.out.println("some exception");

		}
		//for firstname
		driver.findElement(By.cssSelector("input.Format1")).sendKeys("Aanchal");//tag.classname
		//for lastname
		driver.findElement(By.name("txtLN")).sendKeys("Srivastava");
		//for gender radio button
		driver.findElement(By.cssSelector("input[value='Female']")).click();
		//for dob
		driver.findElement(By.name("DtOB")).sendKeys("26/09/1996");
		//for email
		driver.findElement(By.name("Email")).sendKeys("aanchalsrivastava26@gmail.com");
		//for address
		driver.findElement(By.name("Address")).sendKeys("rajajipuram");
		Select drpCity=new Select(driver.findElement(By.name("City")));
		drpCity.selectByVisibleText("Mumbai");
	//	drpCity.selectByIndex(1);
	//	drpCity.selectByIndex(2);
		//for phone no.
		driver.findElement(By.xpath(".//*[@id='txtPhone']")).sendKeys("9153451721");
		//for hobbies checkboxes
		List<WebElement>element=driver.findElements(By.name("chkHobbies"));
		for(WebElement val:element) {
			val.click();
			try {
				Thread.sleep(500);
			}
			catch (InterruptedException e) {
				System.out.println(e.getMessage());
			}
		}
			
			//Examples of get commands
			String actualTitle;
			actualTitle=driver.getTitle();
			System.out.println("page title is :"+actualTitle);
			String expectedTitle="Email Registration Form";
			Boolean b=driver.getPageSource().contains("Email Registration Form");
			if(b==true)
				System.out.println("passed");
			else
				System.out.println("failed");
			
			String currentURL;
			currentURL=driver.getCurrentUrl();
			System.out.println("page current url is :"+currentURL);
			
			//find submit button
			driver.findElement(By.name("submit")).click();
		//	driver.close();
		}
	}

