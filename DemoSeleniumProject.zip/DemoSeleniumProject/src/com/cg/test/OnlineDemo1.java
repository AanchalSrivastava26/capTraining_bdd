package com.cg.test;



import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class OnlineDemo1 {
	public static void main(String[] args) {
		WebDriver driver=new FirefoxDriver();
		driver.get("https://www.awwwards.com/sites/storyblok");
		driver.findElement(By.xpath(".//*[@id='header']/div/div[2]/div[2]/strong/a")).click(); 
	}
}
