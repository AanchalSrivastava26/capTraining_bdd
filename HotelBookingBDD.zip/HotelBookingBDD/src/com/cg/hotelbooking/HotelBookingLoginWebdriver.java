package com.cg.hotelbooking;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class HotelBookingLoginWebdriver {
	static WebDriver driver;
	static String alertMessage;
	public static void main(String[] args) throws InterruptedException {
		String driverPath = "D:\\Selenium\\";
		System.setProperty("webdriver.chrome.driver", driverPath+"chromedriver.exe");	
		driver = new ChromeDriver();
		driver.get("file:///D:/Selenium/login.html");

		//--------------------------------blank and incorrect username---------------------------
		driver.findElement(By.name("userName")).sendKeys("");
		Thread.sleep(200);
		driver.findElement(By.className("btn")).click();
		System.out.println(driver.findElement(By.xpath(".//*[@id='userErrMsg']")).getText());
		driver.findElement(By.name("userName")).sendKeys("aanchal");

		//-------------------------------blank and incorrect password------------------------------
		driver.findElement(By.name("userPwd")).sendKeys("");
		Thread.sleep(200);
		driver.findElement(By.className("btn")).click();
		System.out.println(driver.findElement(By.xpath(".//*[@id='pwdErrMsg']")).getText());
		driver.findElement(By.name("userPwd")).sendKeys("aanchal123");
		driver.findElement(By.className("btn")).click();
		Thread.sleep(3000);
		callAlert();



		driver.findElement(By.name("userName")).clear();
		driver.findElement(By.name("userPwd")).clear();
		//------------------------------username correct password incorrect------------------------------
		driver.findElement(By.name("userName")).sendKeys("capgemini");
		Thread.sleep(200);
		driver.findElement(By.name("userPwd")).sendKeys("aanchal");
		Thread.sleep(200);
		driver.findElement(By.className("btn")).click();
		Thread.sleep(3000);
		callAlert();

		driver.findElement(By.name("userName")).clear();
		driver.findElement(By.name("userPwd")).clear();
		//-------------------------------username incorrect password correct-------------------------------

		driver.findElement(By.name("userName")).sendKeys("aanchal");
		Thread.sleep(200);
		driver.findElement(By.name("userPwd")).sendKeys("capg1234");
		Thread.sleep(200);
		driver.findElement(By.className("btn")).click();
		Thread.sleep(3000);
		callAlert();

		driver.findElement(By.name("userName")).clear();
		driver.findElement(By.name("userPwd")).clear();

		//------------------------------both username and password correct---------------------------------
		driver.findElement(By.name("userName")).sendKeys("capgemini");
		Thread.sleep(200);
		driver.findElement(By.name("userPwd")).sendKeys("capg1234");
		Thread.sleep(200);
		driver.findElement(By.className("btn")).click();


		driver.navigate().to("D:\\Selenium\\Lesson 5-HTML Pages\\App\\success.html");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);


	}
	public static void callAlert()
	{
		String alertMessage= driver.switchTo().alert().getText();
		System.out.println(alertMessage);		
		driver.switchTo().alert().accept();

	}
}