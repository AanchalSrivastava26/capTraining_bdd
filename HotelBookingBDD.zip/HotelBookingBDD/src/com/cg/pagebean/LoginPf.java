package com.cg.pagebean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;


public class LoginPf {

	WebDriver driver;
	
	
	

	public LoginPf(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}



	
		@FindBy(name="userName")
		@CacheLookup
		WebElement lgUserName;
		
		@FindBy(name="userPwd")
		@CacheLookup
		WebElement lgPassword;
	
		@FindBy(how = How.XPATH, using = ".//*[@id='mainCnt']/div/div[1]/form/table/tbody/tr[4]/td[2]/input")
		@CacheLookup
		WebElement lgLoginButton;

		

		public WebElement getLgUserName() {
			return lgUserName;
		}

		public void setLgUserName(String uName) {
			lgUserName.sendKeys(uName);
		}

		public WebElement getLgPassword() {
			return lgPassword;
		}

		public void setLgPassword(String pwd) {
			lgPassword.sendKeys(pwd);
		}

		public WebElement getLgLoginButton() {
			return lgLoginButton;
		}

		public void setLgLoginButton() {
			lgLoginButton.click();
		}
		
}
