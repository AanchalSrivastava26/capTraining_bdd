package com.cg.stepdefinitions;

import static org.testng.Assert.assertTrue;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import com.cg.pagebean.LoginPf;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class HotelLoginStepDefinition {
	static WebDriver driver;

	private LoginPf loginPf;

	@Before
	public void openBrowser() {

		String driverPath = "D:\\Selenium\\";
		System.setProperty("webdriver.chrome.driver", driverPath+"chromedriver.exe");	
		driver = new ChromeDriver();


	}
	@Given("^user is on hotel login page$")
	public void user_is_on_hotel_login_page() throws Throwable {
		loginPf=new LoginPf(driver);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("file:///D:/Selenium/login.html");

	}

	@When("^user enters valid username and password$")
	public void user_enters_valid_username_and_password() throws Throwable {
		loginPf.setLgUserName("capgemini");
		Thread.sleep(1000);
		loginPf.setLgPassword("capg1234");
		Thread.sleep(1000);
		loginPf.setLgLoginButton();
	}

	@Then("^user navigates to success page$")
	public void user_navigates_to_success_page() throws Throwable {
		driver.navigate().to("file:///D:/Selenium/success.html");
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
	}

	@When("^user enters username blank$")
	public void user_enters_username_blank() throws Throwable {
		loginPf.setLgUserName("");
	}

	@When("^user clicks the button$")
	public void user_clicks_the_button() throws Throwable {
		loginPf.setLgLoginButton();
	}

	@Then("^display alert message$")
	public void display_alert_message() throws Throwable {
		assertTrue(driver.getPageSource().contains("* Please enter userName"));
	}
	@When("^user enters user name$")
	public void user_enters_user_name() throws Throwable {
		loginPf.setLgUserName("capgemini");
	}

	@When("^user leaves password blank$")
	public void user_leaves_password_blank() throws Throwable {
		loginPf.setLgPassword("");
		loginPf.setLgLoginButton();

	}

	@Then("^display error message to enter password$")
	public void display_error_message_to_enter_password() throws Throwable {
		assertTrue(driver.getPageSource().contains("* Please enter password"));   
	}

	@When("^user leaves both username and password blank$")
	public void user_leaves_both_username_and_password_blank() throws Throwable {
		loginPf.setLgUserName("");
		loginPf.setLgPassword("");
		loginPf.setLgLoginButton();

	}

	@Then("^display error message to enter user name$")
	public void display_error_message_to_enter_user_name() throws Throwable {
		assertTrue(driver.getPageSource().contains("* Please enter userName"));
	}


	@When("^user enters incorrect username$")
	public void user_enters_incorrect_username() throws Throwable {
		loginPf.setLgUserName("aanchal");
	}

	@When("^user enters incorrect password$")
	public void user_enters_incorrect_password() throws Throwable {
		loginPf.setLgPassword("aanchal");
		loginPf.setLgLoginButton();
	}

	@Then("^display alert message to enter correct username and password$")
	public void display_alert_message_to_enter_correct_username_and_password() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		System.out.println("******" + alertMessage);
	}

	@After
	public void closeBrowser() {
		driver.close();
	}

}
