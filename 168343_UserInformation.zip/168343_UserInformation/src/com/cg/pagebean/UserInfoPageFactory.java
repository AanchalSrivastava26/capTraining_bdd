package com.cg.pagebean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class UserInfoPageFactory {
	WebDriver driver;

	public UserInfoPageFactory(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	// specifying webelements
	@FindBy(how=How.ID,using="rdbCategory")
	@CacheLookup
	WebElement category;
	
	@FindBy(name="txtNM")
	@CacheLookup
	WebElement applicantName;
	
	@FindBy(how=How.ID,using="txtFirstName")
	@CacheLookup
	WebElement firstName;
	
	@FindBy(how=How.ID,using="txtLastName")
	@CacheLookup
	WebElement lastName;
	
	@FindBy(how=How.ID,using="txtFatherName")
	@CacheLookup
	WebElement fatherName;
	
	@FindBy(how=How.ID,using="txtDOB")
	@CacheLookup
	WebElement dob;
	
	@FindBy(how=How.ID,using="rdbFemale")
	@CacheLookup
	WebElement rbFemale;
	
	
	@FindBy(how=How.ID,using="txtMobileNo")
	@CacheLookup
	WebElement mobile;
	
	@FindBy(name="txtEmailID")
	@CacheLookup
	WebElement email;
	
	@FindBy(how=How.ID,using="txtLndLine")
	@CacheLookup
	WebElement landLine;
	
	@FindBy(how=How.ID,using="rdbOfficeAdd")
	@CacheLookup
	WebElement officeAddress;
	
	@FindBy(name="resAddress")
	@CacheLookup
	WebElement residenceAddress;
	
	@FindBy(xpath=".//*[@id='btnSubmit']")
	@CacheLookup
	WebElement submitBtn;
	
	@FindBy(xpath=".//*[@id='btnReset']")
	@CacheLookup
	WebElement resetBtn;
	
	
	//getters and setters

	public WebElement getCategory() {
		return category;
	}

	public void setCategory() {
		category.click();
	}

	public WebElement getApplicantName() {
		return applicantName;
	}

	public void setApplicantName(String name) {
		applicantName.sendKeys(name);
	}

	public WebElement getFirstName() {
		return firstName;
	}

	public void setFirstName(String fName) {
		firstName.sendKeys(fName);
	}

	public WebElement getLastName() {
		return lastName;
	}

	public void setLastName(String lName) {
		lastName.sendKeys(lName);
	}

	public WebElement getFatherName() {
		return fatherName;
	}

	public void setFatherName(String faName) {
		fatherName.sendKeys(faName);
	}

	public WebElement getDob() {
		return dob;
	}

	public void setDob(String db) {
		dob.sendKeys(db);
	}

	public WebElement getRbFemale() {
		return rbFemale;
	}

	public void setRbFemale() {
		rbFemale.click();
	}

	public WebElement getMobile() {
		return mobile;
	}

	public void setMobile(String mbl) {
	mobile.sendKeys(mbl);
	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String mail) {
	email.sendKeys(mail);
	}

	public WebElement getLandLine() {
		return landLine;
	}

	public void setLandLine(String lndline) {
		landLine.sendKeys(lndline);
	}

	public WebElement getOfficeAddress() {
		return officeAddress;
	}

	public void setOfficeAddress() {
		officeAddress.click();
	}

	public WebElement getResidenceAddress() {
		return residenceAddress;
	}

	public void setResidenceAddress(String res) {
	residenceAddress.sendKeys(res);
	}

	public WebElement getSubmitBtn() {
		return submitBtn;
	}

	public void setSubmitBtn() {
		submitBtn.click();
	}

	public WebElement getResetBtn() {
		return resetBtn;
	}

	public void setResetBtn() {
		resetBtn.click();
	}
	
	


}
