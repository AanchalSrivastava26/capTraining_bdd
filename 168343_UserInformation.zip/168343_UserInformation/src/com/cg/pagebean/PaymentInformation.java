package com.cg.pagebean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class PaymentInformation {
	WebDriver driver;

	public PaymentInformation(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	// specifying webelements
	@FindBy(name="txtFN")
	@CacheLookup
	WebElement cdhName;

	@FindBy(name="debit")
	@CacheLookup
	WebElement debitcard;

	@FindBy(name="cvv")
	@CacheLookup
	WebElement cvvNo;

	@FindBy(how=How.ID,using="txtMonth")
	@CacheLookup
	WebElement month;

	@FindBy(how=How.ID,using="txtYear")
	@CacheLookup
	WebElement year;

	@FindBy(xpath=".//*[@id='btnPayment']")
	@CacheLookup
	WebElement payment;
	
	//getters and setters

	public WebElement getCdhName() {
		return cdhName;
	}

	public void setCdhName(String name) {
		cdhName.sendKeys(name);
	}

	public WebElement getDebitcard() {
		return debitcard;
	}

	public void setDebitcard(String dbt) {
		debitcard.sendKeys(dbt);
	}

	public WebElement getCvvNo() {
		return cvvNo;
	}

	public void setCvvNo(String cvv) {
		cdhName.sendKeys(cvv);
	}

	public WebElement getMonth() {
		return month;
	}

	public void setMonth(String mnth) {
		month.sendKeys(mnth);
	}

	public WebElement getYear() {
		return year;
	}

	public void setYear(String yr) {
		year.sendKeys(yr);
	}

	public WebElement getPayment() {
		return payment;
	}

	public void setPayment() {
		payment.click();
	}




}
