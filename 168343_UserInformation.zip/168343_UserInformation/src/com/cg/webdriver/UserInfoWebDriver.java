package com.cg.webdriver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class UserInfoWebDriver {
	static WebDriver driver;
	static String alertMessage;
	public static void main(String[] args) throws InterruptedException {
		String driverPath = "D:\\Selenium\\";
		System.setProperty("webdriver.chrome.driver", driverPath+"chromedriver.exe");	
		driver = new ChromeDriver();
		driver.get("file:///D:/Selenium/WebPages%20UserInformation/UserInformation.html");
		String title=driver.getTitle();
		System.out.println("The page title is :" + title);

		driver.findElement(By.id("rdbCategory")).click();
		Thread.sleep(200);
		
		driver.findElement(By.name("txtNM")).sendKeys("");//blank applicant name
		Thread.sleep(200);
		driver.findElement(By.id("btnSubmit")).click();//click submit button
		Thread.sleep(400);
		callAlert();
		driver.findElement(By.name("txtNM")).sendKeys("Aanchal Srivastava");

		driver.findElement(By.id("txtFirstName")).sendKeys("");//blank first name
		Thread.sleep(200);
		driver.findElement(By.id("btnSubmit")).click();
		Thread.sleep(400);
		callAlert();
		driver.findElement(By.id("txtFirstName")).sendKeys("Aanchal");

		driver.findElement(By.id("txtLastName")).sendKeys("");//blank last name
		Thread.sleep(200);
		driver.findElement(By.id("btnSubmit")).click();
		Thread.sleep(400);
		callAlert();
		driver.findElement(By.id("txtLastName")).sendKeys("Srivastava");

		driver.findElement(By.id("txtFatherName")).sendKeys("");//blank father name
		Thread.sleep(200);
		driver.findElement(By.id("btnSubmit")).click();
		Thread.sleep(400);
		callAlert();
		driver.findElement(By.id("txtFatherName")).sendKeys("Mr. DK Srivastava");

		driver.findElement(By.id("txtDOB")).sendKeys("");//blank dob
		Thread.sleep(200);
		driver.findElement(By.id("btnSubmit")).click();
		Thread.sleep(400);
		callAlert();
		driver.findElement(By.id("txtDOB")).sendKeys("26/09/1996");//invalid dob
		Thread.sleep(200);
		driver.findElement(By.id("btnSubmit")).click();
		Thread.sleep(400);
		callAlert();
	
		
		driver.findElement(By.id("txtDOB")).sendKeys("26-09-1996");
		driver.findElement(By.id("btnReset")).click();
		
		driver.findElement(By.id("rdbCategory")).click();
		Thread.sleep(200);
		driver.findElement(By.name("txtNM")).sendKeys("Aanchal Srivastava");
		Thread.sleep(200);
		driver.findElement(By.id("txtFirstName")).sendKeys("Aanchal");
		Thread.sleep(200);
		driver.findElement(By.id("txtLastName")).sendKeys("Srivastava");
		Thread.sleep(200);
		driver.findElement(By.id("txtFatherName")).sendKeys("Mr. DK Srivastava");
		Thread.sleep(200);
		driver.findElement(By.id("txtDOB")).sendKeys("26-09-1996");
		Thread.sleep(200);
		
		driver.findElement(By.cssSelector("input[value='Female']"));
		Thread.sleep(200);
		driver.findElement(By.id("btnSubmit")).click();
		Thread.sleep(400);
		callAlert();
		driver.findElement(By.cssSelector("input[value='Female']")).click();
		
		driver.findElement(By.id("txtMobileNo")).sendKeys("");
		Thread.sleep(200);
		driver.findElement(By.id("btnSubmit")).click();
		Thread.sleep(400);
		callAlert();
		driver.findElement(By.id("txtMobileNo")).sendKeys("3254367");
		Thread.sleep(200);
		driver.findElement(By.id("btnSubmit")).click();
		Thread.sleep(400);
		callAlert();
		driver.findElement(By.id("txtMobileNo")).sendKeys("7234435610");
		
		driver.findElement(By.name("txtEmailID")).sendKeys("");
		Thread.sleep(200);
		driver.findElement(By.id("btnSubmit")).click();
		Thread.sleep(400);
		callAlert();
		driver.findElement(By.name("txtEmailID")).sendKeys("safdhfj");
		driver.findElement(By.id("btnSubmit")).click();
		Thread.sleep(400);
		callAlert();
		driver.findElement(By.name("txtEmailID")).sendKeys("aanchal@gmail.com");
		
		driver.findElement(By.id("txtLndLine")).sendKeys("");
		Thread.sleep(200);
		driver.findElement(By.id("btnSubmit")).click();
		Thread.sleep(400);
		callAlert();
		driver.findElement(By.id("txtLndLine")).sendKeys("4526627");
		
		driver.findElement(By.cssSelector("input[value='Office']"));
		Thread.sleep(200);
		driver.findElement(By.id("btnSubmit")).click();
		Thread.sleep(400);
		callAlert();
		driver.findElement(By.cssSelector("input[value='Office']")).click();
		
		driver.findElement(By.name("resAddress")).sendKeys("");
		Thread.sleep(200);
		driver.findElement(By.id("btnSubmit")).click();
		callAlert();
		driver.findElement(By.name("resAddress")).sendKeys("rajajipuram,lucknow");
		
		driver.findElement(By.id("btnSubmit")).click();
		
		
		
		
	}
	public static void callAlert()
	{
		String alertMessage= driver.switchTo().alert().getText();
		System.out.println(alertMessage);		
		driver.switchTo().alert().accept();

	}
}
