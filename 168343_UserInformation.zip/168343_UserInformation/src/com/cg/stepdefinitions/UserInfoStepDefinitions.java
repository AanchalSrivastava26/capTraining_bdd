package com.cg.stepdefinitions;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import com.cg.pagebean.UserInfoPageFactory;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class UserInfoStepDefinitions {
	static WebDriver driver;
	private UserInfoPageFactory userInfoPageFactory;
	@Before
	public void openBrowser() {

		String driverPath = "D:\\Selenium\\";
		System.setProperty("webdriver.chrome.driver", driverPath+"chromedriver.exe");	
		driver = new ChromeDriver();



	}
	@Given("^User is on user information page$")
	public void user_is_on_user_information_page() throws Throwable {
		userInfoPageFactory=new UserInfoPageFactory(driver);
		driver.get("file:///D:/Selenium/WebPages%20UserInformation/UserInformation.html");//path for user info page
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@Then("^check the title of the page$")
	public void check_the_title_of_the_page() throws Throwable {
		String title=driver.getTitle();
		System.out.println("The page title is :" + title);
	}

	@When("^user enters all valid data and clicks the submit button$")
	public void user_enters_all_valid_data_and_clicks_the_submit_button() throws Throwable {
		userInfoPageFactory.setCategory();
		userInfoPageFactory.setApplicantName("Aanchal Srivastava");
		userInfoPageFactory.setFirstName("Aanchal");
		userInfoPageFactory.setLastName("Srivastava");
		userInfoPageFactory.setFatherName("Mr. D k Srivastava");
		userInfoPageFactory.setDob("26-09-1996");
		userInfoPageFactory.setRbFemale();
		userInfoPageFactory.setMobile("9890343456");
		userInfoPageFactory.setEmail("aanchal@gmail.com");
		userInfoPageFactory.setLandLine("345163135");
		userInfoPageFactory.setOfficeAddress();
		userInfoPageFactory.setResidenceAddress("rajajipuram lucknow");
		userInfoPageFactory.setSubmitBtn();



	}
	@Then("^navigate to payment page$")
	public void navigate_to_payment_page() throws Throwable {
		driver.navigate().to("file:///D:/Selenium/WebPages%20UserInformation/UserInformation.html");
	}
	@When("^user leaves applicant name blank and clicks the submit button$")
	public void user_leaves_applicant_name_blank_and_clicks_the_submit_button() throws Throwable {
		userInfoPageFactory.setApplicantName("");
		userInfoPageFactory.setSubmitBtn();
	}

	@Then("^display alert message$")
	public void display_alert_message() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(500);
		driver.switchTo().alert().accept();
		System.out.println("******" + alertMessage);
	}

	@When("^user leaves first name blank and clicks the submit button$")
	public void user_leaves_first_name_blank_and_clicks_the_submit_button() throws Throwable {

		userInfoPageFactory.setApplicantName("Aanchal Srivastava");

		userInfoPageFactory.setFirstName("");
		userInfoPageFactory.setSubmitBtn();
	}

	@When("^user leaves last name blank and clicks the submit button$")
	public void user_leaves_last_name_blank_and_clicks_the_submit_button() throws Throwable {


		userInfoPageFactory.setApplicantName("Aanchal Srivastava");
		userInfoPageFactory.setFirstName("Aanchal");
		userInfoPageFactory.setLastName("");
		userInfoPageFactory.setSubmitBtn();
	}

	@When("^user leaves father name blank and clicks the submit button$")
	public void user_leaves_father_name_blank_and_clicks_the_submit_button() throws Throwable {

		userInfoPageFactory.setApplicantName("Aanchal Srivastava");
		userInfoPageFactory.setFirstName("Aanchal");
		userInfoPageFactory.setLastName("Srivastava");
		userInfoPageFactory.setFatherName("");
		userInfoPageFactory.setSubmitBtn();
	}

	@When("^user leaves date blank and clicks the submit button$")
	public void user_leaves_date_blank_and_clicks_the_submit_button() throws Throwable {


		userInfoPageFactory.setApplicantName("Aanchal Srivastava");
		userInfoPageFactory.setFirstName("Aanchal");
		userInfoPageFactory.setLastName("Srivastava");
		userInfoPageFactory.setFatherName("Mr. D k Srivastava");
		userInfoPageFactory.setDob("");
		userInfoPageFactory.setSubmitBtn();
	}

	@When("^user enters invalid date and clicks the submit button$")
	public void user_enters_invalid_date_and_clicks_the_submit_button() throws Throwable {
		userInfoPageFactory.setApplicantName("Aanchal Srivastava");
		userInfoPageFactory.setFirstName("Aanchal");
		userInfoPageFactory.setLastName("Srivastava");
		userInfoPageFactory.setFatherName("Mr. D k Srivastava");
		userInfoPageFactory.setDob("23/09/1987");
		userInfoPageFactory.setSubmitBtn();
	}


	@When("^user leaves gender blank and clicks the submit button$")
	public void user_leaves_gender_blank_and_clicks_the_submit_button() throws Throwable {
		userInfoPageFactory.setApplicantName("Aanchal Srivastava");
		userInfoPageFactory.setFirstName("Aanchal");
		userInfoPageFactory.setLastName("Srivastava");
		userInfoPageFactory.setFatherName("Mr. D k Srivastava");
		userInfoPageFactory.setDob("26-09-1996");
		userInfoPageFactory.setSubmitBtn();

	}

	@When("^user leaves mobile no\\. blank and clicks the submit button$")
	public void user_leaves_mobile_no_blank_and_clicks_the_submit_button() throws Throwable {
		userInfoPageFactory.setApplicantName("Aanchal Srivastava");
		userInfoPageFactory.setFirstName("Aanchal");
		userInfoPageFactory.setLastName("Srivastava");
		userInfoPageFactory.setFatherName("Mr. D k Srivastava");
		userInfoPageFactory.setDob("26-09-1996");
		userInfoPageFactory.setRbFemale();
		userInfoPageFactory.setMobile("");
		userInfoPageFactory.setSubmitBtn();

	}

	@When("^user enters invalid mobile no\\. and clicks the submit button$")
	public void user_enters_invalid_mobile_no_and_clicks_the_submit_button() throws Throwable {
		userInfoPageFactory.setApplicantName("Aanchal Srivastava");
		userInfoPageFactory.setFirstName("Aanchal");
		userInfoPageFactory.setLastName("Srivastava");
		userInfoPageFactory.setFatherName("Mr. D k Srivastava");
		userInfoPageFactory.setDob("26-09-1996");
		userInfoPageFactory.setRbFemale();
		userInfoPageFactory.setMobile("356643");
		userInfoPageFactory.setSubmitBtn();
	}

	@When("^user leaves email id blank and clicks the submit button$")
	public void user_leaves_email_id_blank_and_clicks_the_submit_button() throws Throwable {
		userInfoPageFactory.setApplicantName("Aanchal Srivastava");
		userInfoPageFactory.setFirstName("Aanchal");
		userInfoPageFactory.setLastName("Srivastava");
		userInfoPageFactory.setFatherName("Mr. D k Srivastava");
		userInfoPageFactory.setDob("26-09-1996");
		userInfoPageFactory.setRbFemale();
		userInfoPageFactory.setMobile("9890343456");
		userInfoPageFactory.setEmail("");
		userInfoPageFactory.setSubmitBtn();
	}
	@When("^user enters invalid email and clicks the submit button$")
	public void user_enters_invalid_email_and_clicks_the_submit_button() throws Throwable {
		userInfoPageFactory.setApplicantName("Aanchal Srivastava");
		userInfoPageFactory.setFirstName("Aanchal");
		userInfoPageFactory.setLastName("Srivastava");
		userInfoPageFactory.setFatherName("Mr. D k Srivastava");
		userInfoPageFactory.setDob("26-09-1996");
		userInfoPageFactory.setRbFemale();
		userInfoPageFactory.setMobile("9890343456");
		userInfoPageFactory.setEmail("safdsg");
		userInfoPageFactory.setSubmitBtn();
	}

	@When("^user leaves landline no\\. blank and clicks the submit button$")
	public void user_leaves_landline_no_blank_and_clicks_the_submit_button() throws Throwable {
		userInfoPageFactory.setApplicantName("Aanchal Srivastava");
		userInfoPageFactory.setFirstName("Aanchal");
		userInfoPageFactory.setLastName("Srivastava");
		userInfoPageFactory.setFatherName("Mr. D k Srivastava");
		userInfoPageFactory.setDob("26-09-1996");
		userInfoPageFactory.setRbFemale();
		userInfoPageFactory.setMobile("9890343456");
		userInfoPageFactory.setEmail("aanchal@gmail.com");
		userInfoPageFactory.setLandLine("");
		userInfoPageFactory.setSubmitBtn();
	}

	@When("^user leaves communication blank and clicks the submit button$")
	public void user_leaves_communication_blank_and_clicks_the_submit_button() throws Throwable {
		userInfoPageFactory.setApplicantName("Aanchal Srivastava");
		userInfoPageFactory.setFirstName("Aanchal");
		userInfoPageFactory.setLastName("Srivastava");
		userInfoPageFactory.setFatherName("Mr. D k Srivastava");
		userInfoPageFactory.setDob("26-09-1996");
		userInfoPageFactory.setRbFemale();
		userInfoPageFactory.setMobile("9890343456");
		userInfoPageFactory.setEmail("aanchal@gmail.com");
		userInfoPageFactory.setLandLine("345163135");
		userInfoPageFactory.setSubmitBtn();
	}

	@When("^user leaves address no\\. blank and clicks the submit button$")
	public void user_leaves_address_no_blank_and_clicks_the_submit_button() throws Throwable {
		userInfoPageFactory.setApplicantName("Aanchal Srivastava");
		userInfoPageFactory.setFirstName("Aanchal");
		userInfoPageFactory.setLastName("Srivastava");
		userInfoPageFactory.setFatherName("Mr. D k Srivastava");
		userInfoPageFactory.setDob("26-09-1996");
		userInfoPageFactory.setRbFemale();
		userInfoPageFactory.setMobile("9890343456");
		userInfoPageFactory.setEmail("aanchal@gmail.com");
		userInfoPageFactory.setLandLine("345163135");
		userInfoPageFactory.setOfficeAddress();
		userInfoPageFactory.setResidenceAddress("");
	}

	@After
	public void closeBrowser() {
		driver.close();
	}









}
