package com.cg.stepdefintions;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class HotelBookingStepdefintion {
	
	static WebDriver driver=null;
	static String alertMessage=null;
	String title;
	
	@Before
	public void setUpTestData() {
		driver = new FirefoxDriver();
	
	}
	@Given("^user is on hotel booking page$")
	public void user_is_on_hotel_booking_page() throws Throwable {
	    driver.get("file:///D:/Selenium/Lesson%205-HTML%20Pages/App/hotelbooking.html");
	     title=driver.getTitle();
	}

	@Then("^check title of the page$")
	public void check_title_of_the_page() throws Throwable {
		assertEquals(title, "Hotel Booking");
	  
	}
	
	
}